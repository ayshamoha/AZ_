 <!--start header -->

<nav class="navbar navbar-expand-lg navbar-dark bg-dark"id="mainNav">
    <a class="navbar-brand" href="/"><img style="width: 100%;" src="logo1.png"></a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item" style="background-color: #5ba8ff; padding-top: 3px; padding-bottom: 3px;
         padding-left: 5px; padding-right: 5px; font-size: 15px; border-radius: 5px;">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out" style="color: #fff;"></i> Logout</a>
        </li>
      </ul>
    </div>
  </nav>

 <!--end header -->  